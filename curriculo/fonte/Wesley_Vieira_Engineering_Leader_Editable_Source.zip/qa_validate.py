from pathlib import Path
import json,re,unicodedata,fitz
R=Path(__file__).resolve().parent;A=R/'assets';O=R/'output';Q=R/'qa'
doc=fitz.open(O/'Wesley_Vieira_Engineering_Leader_Complete_Portfolio.pdf');old=fitz.open(R/'source/Wesley_Vieira_Engineering_Leader_Complete_Portfolio.pdf')
def norm(s):return re.sub(r'[^\w]','',unicodedata.normalize('NFKC',s).casefold())
text='\n'.join(p.get_text() for p in doc);n=norm(text);fail=[];checks=[]
def check(label,s):
 if norm(s) not in n:fail.append((label,s))
 else:checks.append(label)
data=json.loads((A/'editorial_content.json').read_text())
for k in ['profile','author_line','career_note','tech_note','award_intro']:check(k,data[k])
for kind,fields in [('roles',['title','context','bullets']),('tech',['title','body']),('recommendations',['name','context','quote']),('press',['meta','title']),('articles',['title','summary','tags','meta']),('article_groups',['intro'])]:
 for i,x in enumerate(data[kind]):
  for f in fields:
   for s in (x[f] if isinstance(x[f],list) else [x[f]]):check(f'{kind}:{i}:{f}',s)
for kind in ['awards','award_captions','press_intro','press_note']:
 for i,s in enumerate(data[kind]):check(f'{kind}:{i}',s)
for i,e in enumerate(json.loads((A/'education_final.json').read_text())):
 for k in ['institution','title','summary','date','status']:check(f'education:{i}:{k}',e[k])
for cr in json.loads((A/'catalog_final.json').read_text()):
 for k in ['title','issuer']:check(f'course:{cr["id"]}:{k}',cr[k])
 if cr['id']>=428:check(f'credential:{cr["id"]}',cr['credential'])
oldurls={l['uri'] for p in old for l in p.get_links() if l.get('uri')};urls={l['uri'] for p in doc for l in p.get_links() if l.get('uri')}
missing_urls=sorted(oldurls-urls)
# Content rectangles, with typography checked independently of decoration.
outside=[]
for pi,p in enumerate(doc):
 for b in p.get_text('dict')['blocks']:
  for l in b.get('lines',[]):
   for s in l['spans']:
    box=fitz.Rect(s['bbox'])
    if box.x0<24 or box.x1>1100 or box.y0<12 or box.y1>782:outside.append((pi+1,s['text'],tuple(box)))
links_bad=[]
for pi,p in enumerate(doc):
 for l in p.get_links():
  if l['kind']==fitz.LINK_GOTO and not 0<=l['page']<len(doc):links_bad.append((pi+1,l))
report={'checks_passed':len(checks),'content_failures':fail,'missing_source_urls':missing_urls,'external_urls':len(urls),'out_of_bounds_spans':outside,'invalid_internal_links':links_bad,'files':{p.name:{'bytes':p.stat().st_size,'pages':len(fitz.open(p))} for p in O.glob('*.pdf')}}
(Q/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
# Original paragraphs that do not occur unchanged, for a separate editorial review.
omitted=[]
for pi,p in enumerate(old):
 for b in p.get_text('blocks'):
  s=' '.join(b[4].split())
  if len(s)>85 and norm(s) not in n:omitted.append((pi+1,s))
(Q/'paragraph_diff.json').write_text(json.dumps(omitted,ensure_ascii=False,indent=2));print('Paragraphs for review:',len(omitted))
