from pathlib import Path
import json,math,fitz
from collections import Counter
from xml.sax.saxutils import escape
from html import unescape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from PIL import Image
from brand_assets import draw_brand
from urllib.parse import urlsplit
R=Path(__file__).resolve().parent;A=R/'assets';O=R/'output';Q=R/'qa'
D=json.loads((A/'editorial_content.json').read_text());E=json.loads((A/'education_final.json').read_text());C=json.loads((A/'catalog_final.json').read_text());ST=json.loads((A/'study_routine.json').read_text())
COURSE_COUNT=len(C); LICENSE_COUNT=COURSE_COUNT-50
for n,f in [('Body','Carlito-Regular.ttf'),('Bold','Carlito-Bold.ttf'),('Italic','Carlito-Italic.ttf'),('Display','LiberationSans-Regular.ttf'),('Heavy','LiberationSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,str(A/'fonts'/f)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
BG='#F0EFEB';INK='#222B32';MUTED='#637078';DARK='#26343C';DARK2='#344950';ACC='#BD5C3B';WHITE='#FFFEFB';LINE='#CFD3D1';TEAL='#337D7B'
def esc(s):return escape(str(s)).replace('–','-').replace('—','-').replace('\u2011','-')
VOL='Volunteered at Expo Longevidade 2022, educating senior citizens about digital security, fraud prevention and online safety. Translated complex cybersecurity risks into practical guidance on social engineering, financial scams, phishing and identity theft, helping participants protect their personal information and use digital services with greater confidence.'
class PDF:
 def __init__(self,name,w=1120,h=790):
  self.w=w;self.h=h;self.name=name;self.c=canvas.Canvas(str(Q/(name+'.pdf')),pagesize=(w,h),pageCompression=1);self.n=0;self.tags={};self.links=[];self.toc=[];self.dark=False
 def rect(self,x,y,w,h,fill,r=0,stroke=None):
  c=self.c;c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.setLineWidth(.5)
  if r:c.roundRect(x,self.h-y-h,w,h,r,fill=1,stroke=bool(stroke))
  else:c.rect(x,self.h-y-h,w,h,fill=1,stroke=bool(stroke))
 def line(self,x,y,x2,y2,co=LINE):
  self.c.setStrokeColor(HexColor(co));self.c.setLineWidth(.65);self.c.line(x,self.h-y,x2,self.h-y2)
 def t(self,s,x,y,fs=12,font='Body',co=None):
  self.c.setFillColor(HexColor(co or (WHITE if self.dark else INK)));self.c.setFont(font,fs);self.c.drawString(x,self.h-y-fs,unescape(esc(s)),charSpace=0)
 def p(self,s,x,y,w,fs=13,leading=None,font='Body',co=None,measure=False):
  p=Paragraph(s,ParagraphStyle('s',fontName=font,fontSize=fs,leading=leading or fs*1.36,textColor=HexColor(co or (WHITE if self.dark else INK)),splitLongWords=False))
  _,h=p.wrap(w,3000)
  if not measure:p.drawOn(self.c,x,self.h-y-h)
  return h
 def img(self,name,x,y,w,h,crop=False):
  path=A/Path(name).name
  im=Image.open(path);iw,ih=im.size;s=(max if crop else min)(w/iw,h/ih);ww,hh=iw*s,ih*s
  self.c.saveState();p=self.c.beginPath();p.circle(x+w/2,self.h-y-h/2,min(w,h)/2) if Path(name).name=='portrait.jpg' else p.rect(x,self.h-y-h,w,h);self.c.clipPath(p,stroke=0,fill=0)
  self.c.drawImage(ImageReader(str(path)),x+(w-ww)/2,self.h-y-h+(h-hh)/2,ww,hh,mask='auto');self.c.restoreState()
 def logo(self,path,x,y,s=36,issuer=None,w=None):
  draw_brand(self,path,x,y,w=w or s,h=s,issuer=issuer)
  if Path(path).name=='bmp.png':self.u('https://raw.githubusercontent.com/docs-petry/imagens/refs/heads/main/bmp-docs/light.png',x,y,s,s)
 def glass(self,x,y,w,h):
  c=self.c;c.saveState();p=c.beginPath();p.roundRect(x,self.h-y-h,w,h,16);c.clipPath(p,stroke=0,fill=0);c.linearGradient(x,self.h-y-h,x+w,self.h-y,[HexColor('#DFE8E3'),HexColor('#F7F6F0')]);c.restoreState();self.rect_outline(x,y,w,h)
 def rect_outline(self,x,y,w,h):
  c=self.c;c.setStrokeColor(HexColor(WHITE));c.setLineWidth(1);c.roundRect(x,self.h-y-h,w,h,16,stroke=1,fill=0)
 def u(self,u,x,y,w,h):
  if u:self.c.linkURL(u,(x,self.h-y-h,x+w,self.h-y),relative=0,thickness=0)
 def link(self,k,x,y,w,h):self.links.append((self.n-1,fitz.Rect(x,y,x+w,y+h),k))
 def start(self,title,section='PROFILE',tag=None,dark=False,subtitle='',rail=''):
  if self.n:self.c.showPage()
  self.n+=1;self.dark=dark;self.rect(0,0,self.w,self.h,DARK if dark else BG)
  self.t('W / V',42,25,14,'Heavy',WHITE if dark else INK);self.t('WESLEY VIEIRA',105,29,10,'Bold',WHITE if dark else INK)
  self.t('SOFTWARE & AGENTIC AI ENGINEERING',self.w-300,29,9,'Bold','#BDC9CA' if dark else MUTED)
  self.line(42,60,self.w-42,60,'#506066' if dark else LINE)
  self.t(section,42,85,10,'Bold','#F0AB8A' if dark else ACC)
  self.t(title,42,107,34,'Display')
  if subtitle:self.p(esc(subtitle),42,153,self.w-84,12,16,co='#C8D3D1' if dark else MUTED)
  if tag:self.tags[tag]=self.n-1;self.toc.append([1,title,self.n])
  self.line(42,self.h-43,self.w-42,self.h-43,'#506066' if dark else LINE)
  labels=[('Profile','profile'),('Career','career'),('Expertise','tech'),('Writing','writing'),('Routine','routine'),('Education','education'),('Courses','catalog')]
  for i,(lab,key) in enumerate(labels):self.t(lab,42+i*(56 if self.w<700 else 82),self.h-29,9,'Body','#C8D3D1' if dark else MUTED);self.link(key,42+i*(56 if self.w<700 else 82),self.h-35,50 if self.w<700 else 70,24)
  self.t(f'{self.n:02}',self.w-70,self.h-31,12,'Bold');self.link('index',self.w-150,self.h-37,72,25);self.t('CONTENTS',self.w-155,self.h-27,8,'Bold','#C8D3D1' if dark else MUTED)
  return 200
 def save(self):
  self.c.save();doc=fitz.open(Q/(self.name+'.pdf'))
  for pg,rect,k in self.links:
   if k in self.tags:doc[pg].insert_link({'kind':fitz.LINK_GOTO,'from':rect,'page':self.tags[k],'to':fitz.Point(0,0)})
  doc.set_toc(self.toc);doc.set_metadata({'title':'Wesley Vieira | Software Engineering Leader','author':'Wesley Vieira','subject':'Engineering leadership, architecture, AI and financial services','keywords':'Software Engineering Leader, Java, AWS, AI, Leadership'})
  for p in doc:doc.xref_set_key(p.xref,'Trans','<< /S /Dissolve /D 0.25 >>')
  out=O/(self.name+'.pdf');doc.save(out,garbage=4,deflate=True);print(out.name,len(doc),out.stat().st_size)
  return out

def bullets(p,items,x,y,w,fs=13,space=10):
 for s in items:
  p.rect(x,y+6,4,4,ACC);y+=p.p(esc(s),x+17,y,w-17,fs,fs*1.4)+space
 return y

p=PDF('Wesley_Vieira_Engineering_Leader_Complete_Portfolio')
# COVER: asymmetric editorial composition.
p.start('','PROFILE',tag='profile',dark=True)
p.rect(0,63,412,684,'#1D292F');p.img('portrait.jpg',43,142,328,328)
p.t('Wesley',454,101,64,'Heavy');p.t('Vieira',454,171,64,'Heavy')
p.t('SOFTWARE ENGINEERING LEADER',457,261,17,'Bold','#E8AE8F');p.t('Software. People. Applied AI.',457,296,25,'Display')
p.p(esc(D['profile']),457,346,607,15,21,co='#E0E5E2')
p.line(457,503,1078,503,'#60716F')
for j,(v,l) in enumerate([('R$800M+','Reported business outcomes'),('15+','Engineers across two squads'),('20+','Systems and services')]):
 xx=457+j*208;p.t(v,xx,526,31,'Heavy','#F0B28E');p.p(l,xx,568,186,11,15,co='#CDD8D5')
p.p('From fraud prevention and product strategy<br/>to leading critical banking engineering.',43,510,316,20,27,'Display')
p.t('Osasco / São Paulo, Brazil',43,627,11,co='#CCD6D4');p.t('+55 11 98553-6310',43,648,11,co='#CCD6D4');p.t('wesleysv11@gmail.com',43,669,11,co='#CCD6D4')
for j,(lab,u) in enumerate([('LinkedIn','https://www.linkedin.com/in/techvieira/'),('GitHub','https://github.com/wesleyvieira99'),('Email','mailto:wesleysv11@gmail.com')]):
 xx=457+j*151;p.t(lab+'  /',xx,653,13,'Bold');p.u(u,xx,646,133,31)
p.t('CAREER & SELECTED WORK  /  OCTOBER 2026',457,705,9,'Bold','#B5C4C0')
# CONTENTS
p.start('A career built across disciplines.','READING GUIDE',tag='index',subtitle='Leadership first. Technical depth next. Evidence and the complete learning record follow.')
sections=[('01','Leadership & career','Accountability, delivery scope and the journey through financial services.','career'),('02','Engineering expertise','Architecture, software, cloud, data, security and applied AI.','tech'),('03','Recognition & contribution','Award-winning work, media coverage, recommendations and volunteering.','recognition'),('04','Technical writing','13 original articles, with covers, summaries, topics and direct links.','writing'),('05','Education & languages','A daily study system, 27 programs, professional credentials and languages.','education'),('06','Complete learning record',f'{COURSE_COUNT} course records from {LICENSE_COUNT} license entries and 50 course entries.','catalog')]
for i,(n,t,b,k) in enumerate(sections):
 xx=42+(i%2)*536;yy=224+(i//2)*147;p.t(n,xx,yy,33,'Display',ACC);p.t(t,xx+62,yy+3,19,'Bold');p.p(b,xx+62,yy+38,425,13,18,co=MUTED);p.line(xx,yy+116,xx+502,yy+116);p.link(k,xx,yy,502,110)
p.t('6h daily study commitment  /  7+ years of consistent learning',42,700,14,'Bold',TEAL);p.link('routine',42,691,720,30)
# CURRENT LEADERSHIP full profile + role detail updated.
p.start('Leading critical engineering.','01 / LEADERSHIP',tag='career',subtitle='Itaú Unibanco  /  Jun 2026 - Present  /  Fraud Prevention  /  São Paulo, Brazil')
p.rect(42,203,292,505,DARK,14);p.logo('itau.png',66,228,49);p.p('Lead Software<br/>Engineer',66,296,242,29,35,'Display',WHITE)
for yy,n,lab in [(408,'2','engineering squads'),(492,'15+','engineers'),(576,'20+','systems and services')]:p.t(n,66,yy,34,'Heavy','#E7AF8E');p.t(lab,66,yy+44,12,co='#D1DAD6')
y=207;y=bullets(p,D['roles'][0]['bullets'],376,y,695,15,15)
y+=7;p.t('ENGINEERING CONTEXT',376,y,10,'Bold',ACC);y+=25
p.p('Bank-wide fraud decisioning spans Pix, debit and credit cards, vehicle and mortgage credit, and cryptocurrency journeys. Modernization connects cloud architecture, legacy decomposition, engineering governance and production reliability.',376,y,687,14,20)
y+=100;p.line(376,y,1078,y);p.t('~1,900',376,y+22,35,'Heavy',TEAL);p.p('legacy files in the modernization landscape, evolving into maintainable AWS services and repositories.',565,y+23,495,14,20)
# CAREER in continuous editorial pages, measured blocks.
def career_page(title,idxs):
 p.start(title,'01 / EXPERIENCE',subtitle='Financial services since 2019: software engineering, product strategy and technical leadership.')
 y=205
 for i in idxs:
  r=D['roles'][i];name=r['employer_date'].split('|')[0].strip();dates=r['employer_date'].split('|')[1].strip()
  p.logo('bradesco.png' if name=='Bradesco' else 'bmp.png' if 'BMP' in name else 'itau.png',42,y,37)
  p.p(esc(name),91,y,214,15,20,'Bold');p.p(esc(dates),91,y+25,214,11,15,co=MUTED)
  p.t(r['title'],334,y,22,'Bold');yy=y+34
  if r['context']:yy+=p.p(esc(r['context']),334,yy,735,12,17,co=MUTED)+10
  yy=bullets(p,r['bullets'],334,yy,737,13,8)
  y=yy+18;p.line(42,y-9,1078,y-9)
 assert y<729,(title,y)
career_page('Building credit at banking scale.',[1])
# extra whitespace on bradesco used for leadership operating model (source-derived)
p.glass(334,565,744,131);p.t('THE LEADERSHIP RESPONSIBILITY',355,584,10,'Bold',ACC);p.p('Architecture and technical judgment. Delivery alignment. Production stability. Mentoring and career development. Decisions made with Product, Security, Infrastructure, Operations and Business.',355,611,695,15,21)
career_page('From product strategy to software.',[2,3])
career_page('The foundations of the journey.',[4,5,6,7])
p.p(esc(D['career_note']),42,696,1036,10,14,co=MUTED)
# technology panels editorial rows, every original body preserved
for z,ids in enumerate([[0,1,2,3],[4,5,6,7],[8,9,10]]):
 p.start(['Architecture, languages & delivery.','Cloud, reliability & security.','Data, intelligence & experience.'][z],'02 / ENGINEERING EXPERTISE',tag='tech' if z==0 else None,subtitle='Technical breadth grounded in regulated financial systems and hands-on engineering.')
 for j,i in enumerate(ids):
  t=D['tech'][i];xx=42+(j%2)*536;yy=215+(j//2)*221;p.t(f'{i+1:02}',xx,yy,26,'Display',ACC);p.t(t['title'],xx+49,yy+4,18,'Bold')
  p.p(esc(t['body']),xx+49,yy+41,450,14,20);p.line(xx,yy+195,xx+500,yy+195)
 p.p(esc(D['tech_note']),42,696,1036,11,15,co=MUTED)
# recognition and all images
p.start('Engineering with visible consequences.','03 / RECOGNITION',tag='recognition',subtitle='Walther Moreira Salles Award  /  Itaú Unibanco  /  December 2023')
p.img(D['photos'][0],42,201,627,325)
p.rect(692,201,386,325,DARK,12);p.t('R$350M',714,229,45,'Heavy','#F0B18C');p.p('Reported fraud-loss mitigation in the first year of the WhatsApp alert initiative.',715,292,337,17,24,co=WHITE);p.p(esc(D['award_intro']),715,393,337,12,17,co='#D5DFDB')
p.img(D['photos'][1],42,548,190,137);p.img(D['photos'][2],249,548,131,137)
y=548
for s in D['awards']:y+=p.p(esc(s),410,y,668,12,17)+12
for j,(x,w) in enumerate([(42,627),(42,190),(249,131)]):
 yy=531 if j==0 else 688;p.p(esc(D['award_captions'][j]),x,yy,w,8,10,co=MUTED)
# financial outcomes + press
p.start('Business impact. Public evidence.','03 / IMPACT & MEDIA',subtitle=' '.join(D['press_intro']))
for j,(num,title,body) in enumerate([('R$350M','Customer protection','WhatsApp fraud alerts and immediate customer validation.'),('R$300M','Fraud-loss savings','ML automation and an AWS SageMaker pipeline integrated with legacy TCP/IP systems.'),('R$150M+','New credit revenue','Investment-backed personal-credit platform and digital credit delivery.')]):
 yy=207+j*159;p.t(num,42,yy,38,'Heavy',TEAL);p.t(title,42,yy+49,17,'Bold');p.p(body,42,yy+78,315,13,18,co=MUTED)
p.t('MEDIA COVERAGE',421,203,11,'Bold',ACC);y=229
for a in D['press']:
 p.logo(a['logo'],421,y+5,36,issuer=a['meta'].split(' / ')[0],w=90)
 p.t(a['meta'],529,y,10,'Bold',MUTED)
 h=p.p(esc(a['title']),529,y+19,544,13.5,17,'Bold')
 by=y+22+h;p.t('READ COVERAGE  >',529,by,9,'Bold',TEAL)
 p.t(urlsplit(a['url']).netloc.replace('www1.','').replace('www.',''),665,by,9,'Body',MUTED)
 p.u(a['url'],421,y+5,90,36);p.u(a['url'],529,y+18,544,h);p.u(a['url'],525,by-2,128,17)
 y+=87;p.line(421,y-9,1078,y-9)
p.p(esc(' '.join(D['press_note'])),421,684,650,10,14,co=MUTED)
# testimonials on two pages variable size + volunteer
for batch in [D['recommendations'][:2],D['recommendations'][2:]]:
 p.start('What colleagues say.','03 / RECOMMENDATIONS',subtitle='Original recommendations, preserved in Portuguese.')
 y=205
 for rr in batch:
  h=p.p(esc(rr['quote']),42,y,730,15,22,measure=True);p.p(esc(rr['quote']),42,y,730,15,22)
  p.line(817,y,817,y+h);p.p(esc(rr['name']),845,y,230,17,22,'Bold');p.p(esc(rr['context']),845,y+55,230,11,16,co=MUTED);y+=max(h,105)+38
 assert y<733,('recommendations',y)
p.start('Making security understandable.','03 / COMMUNITY CONTRIBUTION',subtitle='Volunteer security speaker  /  Expo Longevidade 2022  /  Banco Itaú  /  October 2022')
p.t('Technology serves people.',42,227,43,'Display',TEAL);p.p(esc(VOL),42,307,686,20,30)
p.rect(804,214,274,400,DARK,15);p.t('Focus areas',826,244,22,'Bold',WHITE)
for i,s in enumerate(['Digital safety','Fraud prevention','Social engineering','Phishing & identity theft','Customer education']):p.p(esc(s),826,299+i*54,228,16,22,co='#DFE8E1')
p.p('The same thread runs through the career: understand risk, translate complexity and turn technology into practical protection.',42,614,720,16,23,'Italic',MUTED)
# Writing introduction retains the full thematic framing.
p.start('Writing as engineering contribution.','04 / ORIGINAL TECHNICAL WRITING',tag='writing',subtitle=D['author_line'])
for i,g in enumerate(D['article_groups']):
 yy=207+i*97;p.t(f'{i+1:02}',42,yy,29,'Display',ACC);p.t(g['title'],106,yy,20,'Bold');p.p(esc(g['intro']),106,yy+32,956,14,20);p.line(42,yy+81,1078,yy+81)
# WRITING, 2 readable stories / page
for k in range(0,len(D['articles']),2):
 p.start('Ideas made accessible.','04 / ORIGINAL TECHNICAL WRITING',tag=None,subtitle=D['author_line'])
 for j,a in enumerate(D['articles'][k:k+2]):
  xx=42+j*536;p.rect(xx,207,500,210,DARK);p.img(a['image'],xx,207,500,210,False);p.t(a['meta'],xx,432,10,'Bold',TEAL)
  hh=p.p(esc(a['title']),xx,456,497,22,27,'Bold');yy=456+hh+14
  yy+=p.p(esc(a['summary']),xx,yy,497,13.5,19)+15
  yy+=p.p(esc(a['tags']),xx,yy,497,10,14,'Bold',ACC)+12
  by=min(yy,697);p.rect(xx,by,132,26,TEAL,6);p.t('READ ARTICLE  >',xx+13,by+7,9,'Bold',WHITE);p.t('linkedin.com',xx+149,by+7,9,'Body',MUTED);p.u(a['url'],xx,by,132,26);p.u(a['url'],xx,207,500,210);p.u(a['url'],xx,456,497,hh)
  assert yy<724,('article',a['id'],yy)
# STUDY ROUTINE / Calendar-grounded, separate from completion history.
p.start('The discipline behind the depth.','05 / DAILY STUDY ROUTINE',tag='routine',subtitle='A six-hour daily commitment, supported by a recurring seven-day learning calendar.')
p.rect(42,205,312,386,DARK,16)
p.t('6h',66,225,86,'Heavy',WHITE);p.t('DAILY STUDY COMMITMENT',69,331,11,'Bold','#A7C5BD')
p.line(66,368,329,368,'#52676A');p.t('7 days',66,388,30,'Display',WHITE);p.p('A place for learning every day.',66,432,260,14,20,co='#DAE4DF')
p.t('7+ years',66,481,30,'Display',WHITE);p.p('Of consistent study and continued development.',66,525,260,14,20,co='#DAE4DF')
p.p(esc(ST['intro']),389,208,685,18,26,'Body')
items=[('Engineering','Software, cloud, security, data and AI.','9h / week'),('Languages & review','Daily English, rotating languages and consolidation.','24h30 / week'),('Academic programs','Time reserved for academic coursework.','4h15 / week'),('Math & algorithms','Foundations, theory and problem solving.','3h30 / week'),('Certifications','Structured professional credential study.','3h15 / week'),('Leadership','Learning about people, decisions and influence.','2h / week')]
for i,(title,body,time) in enumerate(items):
 x=389+(i%2)*352;y=330+(i//2)*97
 p.t(f'{i+1:02}',x,y,11,'Bold',ACC);p.t(title,x+30,y-2,16,'Bold');p.p(esc(body),x+30,y+24,289,12,16,co=MUTED);p.t(time,x+30,y+64,10,'Bold',TEAL)
p.glass(42,619,1036,97);p.t('PLANNED, PROTECTED, REPEATED.',64,638,11,'Bold',TEAL);p.p('The current calendar reserves 6h15 to 7h per day, with 46h30 across the week. Time blocks give each learning priority a clear place and keep review part of the routine.',64,661,985,14,20)
# Two readable weekly spreads preserve every active study block.
for page_days in [ST['days'][:4],ST['days'][4:]]:
 p.start('How I organize the week.','05 / STUDY CALENDAR',subtitle='Current recurring plan from 12 Oct 2026. São Paulo time (UTC-3). Planned blocks, not an attendance log.')
 cols=len(page_days);gap=22;cw=(1036-gap*(cols-1))/cols
 for i,day in enumerate(page_days):
  x=42+i*(cw+gap);p.rect(x,207,cw,507,WHITE,12);p.t(day['name'],x+16,224,19,'Bold');mins=day['minutes'];p.t(f"{mins//60}h{mins%60:02} planned",x+16,253,11,'Bold',TEAL);p.line(x+16,278,x+cw-16,278)
  for j,b in enumerate(day['blocks']):
   y=290+j*30;p.t(b['start'],x+16,y,10,'Bold',TEAL);p.p(esc(b['title']),x+62,y-1,cw-75,11,13);p.t(f"{b['minutes']}m",x+16,y+13,8,'Body',MUTED)
 if cols==3:
  p.t('Saturday includes a break from 06:45 to 08:30. Each language block is 30 minutes.',42,726,9,'Body',MUTED)

# EDUCATION 3 per page, same data preserved; group by purpose
G=[('Leadership & business',[23,19,6]),('Cognition & human behavior',[22,0,17]),('AI engineering & machine learning',[15,18,16]),('Data & algorithms',[4,5,12]),('Mathematics & quantum computing',[25,26,13]),('Foundations of engineering',[14,2]),('Software & cybersecurity',[1,11,24]),('Communication in English',[3,8,9]),('Academic communication',[10,7]),('Global communication',[20,21])]
assert sorted(i for _,ids in G for i in ids)==list(range(len(E))), 'Education group coverage'
for gi,(title,ids) in enumerate(G):
 p.start(title,'05 / EDUCATION',tag='education' if gi==0 else None,subtitle='Academic qualifications and continuing education. Completion status is shown for each program.')
 y=204
 for idx in ids:
  e=E[idx];p.logo(e['logo'],42,y,47,issuer=e['institution']);ih=p.p(esc(e['institution']),103,y,224,14,18,'Bold');dy=max(ih+8,44);p.p(esc(e['date']),103,y+dy,224,10,14,co=MUTED);lh=dy+20+p.p(esc(e['status']),103,y+dy+20,224,10,14,'Bold',TEAL)
  h=p.p(esc(e['title']),355,y,723,18,23,'Bold');h+=12+p.p(esc(e['summary']),355,y+h+12,723,12.5,17.5)
  if e.get('credential_url'):
   p.t(e['credential_label']+'  >',355,y+h+9,10,'Bold',TEAL);p.u(e['credential_url'],355,y+h+5,400,22);h+=31
  y+=max(100,h,lh)+29;p.line(42,y-14,1078,y-14)
 assert y<731,('education',title,y)
# LANGUAGES and selected professional credentials
from language_flags import flag
p.start('A global perspective.','05 / LANGUAGES & CONTINUOUS LEARNING')
langs=[('br','Portuguese'),('gb','English'),('es','Spanish'),('cn','Mandarin Chinese'),('fr','French'),('de','German'),('it','Italian'),('nl','Dutch'),('gr','Greek'),('in','Hindi'),('jp','Japanese'),('kr','Korean')]
for i,(code,name) in enumerate(langs):
 x=42+(i%3)*352;y=217+(i//3)*89;p.c.saveState();p.c.translate(0,p.h-841.89);flag(p.c,code.upper(),x,y,42,28);p.c.restoreState();p.t(name,x+59,y+5,17,'Bold');p.line(x,y+58,x+306,y+58)
p.glass(42,597,1036,119);p.t('6h',66,615,47,'Heavy',TEAL);p.t('Daily study, deliberately organized.',195,618,26,'Display');p.p('A six-hour daily commitment. More than seven years of consistent learning across engineering, leadership, mathematics and communication. Explore the weekly routine.',195,660,830,14,20);p.link('routine',42,597,1036,119)
# Credentials preserve all list from original source
credentials=[('AWS Certified AI Practitioner','AWS | Issued Sep 2026, expires Sep 2029'),('AWS Certified Solutions Architect - Associate','AWS'),('AWS Certified Developer - Associate','AWS'),('AWS Certified Cloud Practitioner','AWS'),('Microsoft Certified: Azure Fundamentals (AZ-900)','Microsoft'),('Professional Scrum Product Owner II (PSPO II)','Scrum.org'),('Scrum Fundamentals Certified (SFC)','SCRUMstudy'),('Scrum Foundation Professional Certificate (SFPC)','CertiProf'),('Apache Kafka Confluent Fundamentals Accreditation','Confluent')]
p.start('Professional credentials.','05 / CERTIFICATIONS',subtitle='Cloud, AI, product ownership, Scrum and event streaming.')
for i,(t,issuer) in enumerate(credentials):
 x=42+(i%3)*352;y=211+(i//3)*161;p.t(f'{i+1:02}',x,y,24,'Display',ACC);brand=issuer.split(' | ')[0];logo=next((r['logo'] for r in C if r['issuer']==brand or brand=='AWS' and 'Amazon Web Services' in r['issuer'] or brand=='SCRUMstudy' and 'SCRUMstudy' in r['issuer']), 'course_logo_21.png');p.logo(logo,x+239,y,31,issuer=brand,w=65);h=p.p(esc(t),x,y+38,300,16,21,'Bold');p.p(esc(issuer),x,y+45+h,300,11,16,co=MUTED);p.line(x,y+145,x+312,y+145)
# Complete courses grouped, 2 columns, dynamic rows, preserving issuer date id links.
counts=Counter(x['category'] for x in C);categories=list(counts)
p.start('The complete learning record.','06 / COURSES & CERTIFICATIONS',tag='catalog',subtitle=f'{COURSE_COUNT} records in one consolidated catalog. Original titles, issuers, dates and credential identifiers are retained.')
p.t(str(COURSE_COUNT),42,204,82,'Heavy',TEAL);p.t('COURSE RECORDS',47,300,12,'Bold',MUTED)
p.p(f'{LICENSE_COUNT} license and certification entries<br/>+ 50 course entries',42,351,300,20,28,'Display')
p.p('Course titles open their credential pages where links are available. The catalog preserves the original records, including exam preparation and professional certifications.',42,468,290,13,19,co=MUTED)
for i,cat in enumerate(categories):
 yy=205+i*47;p.t(f'{i+1:02}',402,yy,14,'Bold',ACC);p.t(cat,451,yy,15,'Bold');p.t(str(counts[cat]),1032,yy,15,'Bold',TEAL);p.line(402,yy+35,1078,yy+35);p.link('cat'+str(i),402,yy-4,676,39)
col=0;y=207
p.start('Courses & certifications.','06 / COMPLETE COURSE CATALOG',subtitle='Original titles, providers and credential details. Select a title to open its credential.')
def nextcol():
 global col,y
 if col==0:col=1;y=207
 else:p.start('Courses & certifications.','06 / COMPLETE COURSE CATALOG',subtitle='Original titles, providers and credential details. Select a title to open its credential.');col=0;y=207
for ci,cat in enumerate(categories):
 subset=[x for x in C if x['category']==cat]
 if y+112>725:nextcol()
 elif y>207:y+=12
 p.tags['cat'+str(ci)]=p.n-1
 x=42+col*536;p.t(cat,x,y,15,'Bold',TEAL);y+=34
 for row in subset:
  title=esc(row['title']);issuer=esc(row['issuer']);detail=' · '.join(x for x in [row.get('date',''),('ID: '+row['credential']) if row.get('credential') else ''] if x)
  tw=423;h1=p.p(title,0,0,tw,10.5,12.5,'Bold',measure=True);h2=p.p(issuer,0,0,tw,9,11,measure=True);h3=p.p(esc(detail),0,0,tw,7.8,9.5,measure=True) if detail else 0
  urls=list(dict.fromkeys(row.get('links',[])));extra=15 if len(urls)>1 else 0
  hh=max(36,h1+h2+h3+5)+13+extra
  if y+hh>725:
   nextcol();x=42+col*536;p.t(cat,x,y,15,'Bold',TEAL);y+=34
  x=42+col*536;p.logo(row['logo'],x,y+2,34,issuer=row['issuer'],w=60);p.p(title,x+77,y,tw,10.5,12.5,'Bold');p.p(issuer,x+77,y+h1+2,tw,9,11,co=MUTED)
  if detail:p.p(esc(detail),x+77,y+h1+h2+4,tw,7.8,9.5,co=MUTED)
  if urls:p.u(urls[0],x+75,y-1,tw+2,h1+3)
  for n,u in enumerate(urls[1:]):
   lx=x+77+n*105;ly=y+hh-21;p.t('REFERENCE '+str(n+2)+' >',lx,ly,7.5,'Bold',TEAL);p.u(u,lx,ly-1,97,12)
  p.line(x,y+hh-7,x+500,y+hh-7);y+=hh
full=p.save()
# Executive CV: actual 4-page portrait application document.
s=PDF('Wesley_Vieira_Engineering_Leader_Executive',595.28,841.89)
def exstart(title,tag):
 s.start('',tag.upper(),tag=tag);s.rect(0,61,595.28,118,DARK);s.t(title,42,89,27,'Display',WHITE);s.t('Wesley Vieira / Software Engineering Leader',42,133,11,'Body','#D0DCD8');return 202
def exrole(i,y,fs=10.4):
 r=D['roles'][i];s.t(r['title'],42,y,14,'Bold');y+=22;s.p(esc(r['employer_date']),42,y,511,10,13,'Bold',TEAL);y+=20
 if r['context']:y+=s.p(esc(r['context']),42,y,511,9,12,co=MUTED)+7
 y=bullets(s,r['bullets'],42,y,511,fs,6);s.line(42,y+3,553,y+3);return y+20
s.start('','PROFILE',tag='profile');s.rect(0,61,595.28,218,DARK);s.t('Wesley Vieira',42,91,38,'Heavy',WHITE);s.p('Software Engineering Leader<br/>Software & Agentic AI',42,148,365,19,26,'Display',WHITE);s.img('portrait.jpg',438,99,112,112)
s.p('Osasco / São Paulo, Brazil<br/>+55 11 98553-6310  |  wesleysv11@gmail.com',42,219,505,10,14,co='#D9E3DE')
s.p(esc(D['profile']),42,304,511,12,17)
s.t('CAREER IMPACT',42,428,10,'Bold',ACC)
for j,(v,t) in enumerate([('R$350M','Fraud-loss mitigation'),('R$300M','ML-driven fraud savings'),('R$150M+','New credit revenue')]):
 x=42+j*174;s.t(v,x,453,24,'Heavy',TEAL);s.p(t,x,486,157,10,14,co=MUTED)
s.t('CURRENT LEADERSHIP',42,530,10,'Bold',ACC)
y=exrole(0,555,10.2)
assert y<798,('exec1',y)
for x,lab,u in [(42,'LinkedIn','https://www.linkedin.com/in/techvieira/'),(170,'GitHub','https://github.com/wesleyvieira99')]:s.t(lab,x,780,10,'Bold',TEAL);s.u(u,x,776,100,20)
y=exstart('Experience & progression.','career');y=exrole(1,y,10.5);y=exrole(2,y,10.5)
for i in [3,4,5,6,7]:
 r=D['roles'][i];s.p(esc(r['title']+' | '+r['employer_date']),42,y,511,10.2,14,'Bold');y+=24
assert y<790,('exec2',y)
y=exstart('Engineering depth.','tech')
for r in D['tech']:
 s.t(r['title'],42,y,11.5,'Bold',TEAL);y+=18;y+=s.p(esc(r['body']),42,y,511,9.3,12.4)+11
assert y<797,('exec3',y)
y=exstart('Evidence & continuous development.','education')
s.t('SELECTED QUALIFICATIONS',42,y,10,'Bold',ACC);y+=25
for i in [2,6,23,19,15,18]:
 e=E[i];y+=s.p(esc(e['institution']+' | '+e['title']),42,y,511,10.5,14,'Bold');y+=s.p(esc(e['date']+' | '+e['status']),42,y+3,511,9,12,co=MUTED)+12
s.t('PROFESSIONAL CREDENTIALS',42,y+2,10,'Bold',ACC);y+=25
y+=s.p('AWS AI Practitioner, Solutions Architect - Associate, Developer - Associate and Cloud Practitioner. Microsoft Azure Fundamentals (AZ-900). PSPO II. SFC. SFPC. Confluent Fundamentals Accreditation.',42,y,511,10.5,15)+19
s.t('RECOGNITION & CONTRIBUTION',42,y,10,'Bold',ACC);y+=24
y+=s.p('Walther Moreira Salles Award, Itaú Unibanco, December 2023. WhatsApp fraud-alert initiative associated with R$350M in reported fraud-loss mitigation. Volunteer security speaker at Expo Longevidade 2022.',42,y,511,10.5,15)+18
y+=s.p(f'Author of 13 technical articles. {COURSE_COUNT} course records. Latest study: Stanford algorithms, completed Johns Hopkins Algebra, Imperial mathematics for ML, postgraduate Quantum Computing and a completed Vanderbilt course in AI agents with Python. A 6h daily study commitment, seven days a week. More than seven years of consistent learning.',42,y,511,10.5,15)+19
s.t('LANGUAGES',42,y,10,'Bold',ACC);y+=23
for i,(code,name) in enumerate(langs):
 xx=42+(i%3)*174;yy=y+(i//3)*26;flag(s.c,code.upper(),xx,yy,22,14);s.t(name,xx+29,yy,9.5,'Body')
y+=102
assert y<797,('exec4',y)
# A dedicated, spacious page avoids compressing the four existing pages.
y=exstart('A discipline of daily learning.','routine')
s.glass(42,y,511,115);s.t('6h',60,y+10,56,'Heavy',TEAL);s.t('DAILY STUDY COMMITMENT',176,y+19,10,'Bold',TEAL);s.p('Seven days a week.<br/>More than seven years of consistent learning.',176,y+43,350,12,17)
y+=141;y+=s.p(esc(ST['intro']),42,y,511,11,16)+25
s.t('A TYPICAL MONDAY / SÃO PAULO TIME',42,y,10,'Bold',ACC);y+=25
blocks=[('01:30 - 02:00','Leadership and mathematics'),('02:00 - 03:00','Certifications and academic programs'),('03:00 - 04:45','Technical study and algorithms'),('04:45 - 07:45','English, Spanish, Dutch, French, German and Italian'),('07:45 - 08:15','Language review and consolidation')]
for time,title in blocks:
 s.t(time,42,y,10,'Bold',TEAL);h=s.p(esc(title),170,y,383,11,15);y+=max(h,18)+13;s.line(42,y-6,553,y-6)
y+=14;s.t('THE WEEKLY RHYTHM',42,y,10,'Bold',ACC);y+=25
y+=s.p('English every day. Spanish, Dutch, French, German and Italian on Monday, Wednesday, Friday and Sunday. Mandarin, Hindi, Japanese, Korean and Greek on Tuesday, Thursday and Saturday. Leadership, foundations, technical study, academic work and certification study have recurring places throughout the week.',42,y,511,11,16)+19
s.p('Current recurring calendar from 12 Oct 2026: 6h15 to 7h of planned study per day. The complete portfolio includes every daily time block.',42,y,511,9,13,co=MUTED)
assert y+30<797,('exec_routine',y)
s.tags.update({'writing':3,'catalog':3,'index':0});exe=s.save()
(Q/'manifest.json').write_text(json.dumps({'full_pages':p.n,'executive_pages':s.n,'tags':p.tags,'data_counts':{'courses':len(C),'education':len(E),'articles':len(D['articles']),'roles':len(D['roles'])}},indent=2))
