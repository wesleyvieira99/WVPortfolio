"""Package editable CV source after the final build and visual review.

Asset names are retained because brand_config.json aliases are part of the
renderer contract. Only machine-specific logo paths in archived final record
files are normalized; working JSON sources remain unchanged.
"""
from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
OUTPUT = ROOT / 'output'
ARCHIVE = OUTPUT / 'Wesley_Vieira_Engineering_Leader_Editable_Source.zip'
MAX_ARCHIVE_BYTES = 10_000_000
SCRIPTS = (
    'build.py', 'brand_assets.py', 'language_flags.py', 'qa_validate.py',
    'review.py', 'package_source.py', 'README.md',
)
BASELINE = 'source/Wesley_Vieira_Engineering_Leader_Complete_Portfolio.pdf'
QA_REPORTS = (
    'validation.json', 'review.json', 'paragraph_diff.json', 'manifest.json',
    'update_notes.json', 'articles_verified_20261007.json',
)
PORTABLE_LOGO_RECORDS = {'education_final.json', 'catalog_final.json'}


def portable_records(path):
    """Keep every record and field, normalizing only a local logo path."""
    rows = json.loads(path.read_text(encoding='utf-8'))
    for row in rows:
        if row.get('logo'):
            name = Path(row['logo']).name
            if not (ASSETS / name).is_file():
                raise FileNotFoundError(f'Missing record logo: {name}')
            row['logo'] = 'assets/' + name
    return json.dumps(rows, ensure_ascii=False, indent=2) + chr(10)


def check_required_files():
    for relative in (*SCRIPTS, BASELINE):
        if not (ROOT / relative).is_file():
            raise FileNotFoundError(f'Missing source file: {relative}')
    config = json.loads((ASSETS / 'brand_config.json').read_text(encoding='utf-8'))
    # Validate both alias maps without altering their keys or destinations.
    for mapping in ('issuers', 'files'):
        for label, spec in config[mapping].items():
            if spec.get('file') and not (ASSETS / spec['file']).is_file():
                raise FileNotFoundError(f'Missing brand asset for {label}: {spec["file"]}')
    for relative in ('editorial_content.json', 'education_final.json', 'catalog_final.json'):
        if not (ASSETS / relative).is_file():
            raise FileNotFoundError(f'Missing content data: {relative}')


def main():
    check_required_files()
    OUTPUT.mkdir(exist_ok=True)
    temporary = ARCHIVE.with_suffix('.zip.tmp')
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for relative in SCRIPTS:
                archive.write(ROOT / relative, relative)
            # Preserve names for every image, SVG, font and JSON source.
            # In particular, brand_config.json is copied byte-for-byte.
            for path in sorted(ASSETS.rglob('*')):
                if not path.is_file() or '__pycache__' in path.parts:
                    continue
                relative = path.relative_to(ROOT).as_posix()
                if path.parent == ASSETS and path.name in PORTABLE_LOGO_RECORDS:
                    archive.writestr(relative, portable_records(path))
                else:
                    archive.write(path, relative)
            archive.write(ROOT / BASELINE, BASELINE)
            for name in QA_REPORTS:
                path = ROOT / 'qa' / name
                if path.is_file():
                    archive.write(path, 'qa/' + name)
        size = temporary.stat().st_size
        if size > MAX_ARCHIVE_BYTES:
            raise ValueError(f'Source archive exceeds 10 MB: {size:,} bytes')
        temporary.replace(ARCHIVE)
        print(ARCHIVE)
        print(f'{size:,} bytes')
    finally:
        if temporary.exists():
            temporary.unlink()


if __name__ == '__main__':
    main()
