"""Consistent, source-faithful brand wells for the CV PDF.

Existing raster assets are embedded unchanged. Visible bounds are measured and
positioned with a native PDF clip; no image is recoloured, stretched or edited.
"""
from functools import lru_cache
from pathlib import Path
import json
from PIL import Image
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
CONFIG = json.loads((ASSETS / 'brand_config.json').read_text())


def brand_spec(path, issuer=None):
    """Resolve by issuer first, then source filename; issuer is preferred."""
    filename = Path(path).name if path else ''
    spec = dict(CONFIG['files'].get(filename, {}))
    if issuer:
        key = str(issuer).split(' / ')[0].strip()
        spec.update(CONFIG['issuers'].get(key, {}))
    spec.setdefault('file', filename)
    return spec


@lru_cache(maxsize=128)
def _image_info(filename):
    path = ASSETS / filename
    with Image.open(path) as source:
        im = source.convert('RGBA')
        iw, ih = im.size
        alpha = im.getchannel('A')
        # A threshold ignores effectively invisible antialiasing fringes.
        bbox = alpha.point(lambda a: 255 if a > 6 else 0).getbbox() or (0, 0, iw, ih)
        transparent = alpha.getextrema()[0] < 245
        if not transparent:
            bbox = (0, 0, iw, ih)
        pixels = list(im.getdata())
        foreground = [p for p in pixels if p[3] > 160]
        light_fraction = sum(min(p[:3]) > 215 for p in foreground) / max(1, len(foreground))
        dark = transparent and light_fraction > 0.6
    return iw, ih, bbox, dark


def _neutral(pdf, x, y, w, h):
    """Neutral certificate symbol, never an invented provider identity."""
    pdf.rect(x, y, w, h, '#F4F5F2', 5, '#DCE1DE')
    c = pdf.c
    c.saveState()
    c.setStrokeColor(HexColor('#64757A'))
    c.setLineWidth(0.9)
    sw, sh = min(w * .40, 18), min(h * .64, 24)
    xx, yy = x + (w-sw)/2, y + (h-sh)/2
    c.roundRect(xx, pdf.h-yy-sh, sw, sh, 1.4, stroke=1, fill=0)
    for dy, frac in [(sh*.28, .62), (sh*.44, .62), (sh*.60, .42)]:
        c.line(xx+sw*.18, pdf.h-yy-dy, xx+sw*(.18+frac), pdf.h-yy-dy)
    c.restoreState()


def draw_brand(pdf, path, x, y, w=60, h=36, issuer=None):
    """Draw a logo at top-left coordinates in a consistent, high-contrast well.

    Recommended dimensions: courses 72x38, education 48x48, press 100x38.
    Pass issuer from the record so missing-provider rows stay neutral and old
    misassociated file names cannot override the correct organisation.
    """
    spec = brand_spec(path, issuer)
    filename = spec.get('file')
    if spec.get('neutral') or not filename or not (ASSETS/filename).is_file():
        _neutral(pdf, x, y, w, h)
        return
    if filename.lower().endswith('.svg'):
        _draw_svg(pdf, filename, spec, x, y, w, h)
        return
    iw, ih, bbox, auto_dark = _image_info(filename)
    bg = spec.get('background', '#263A46' if auto_dark else '#FFFFFF')
    border = '#445862' if bg != '#FFFFFF' else '#DCE1DE'
    pdf.rect(x, y, w, h, bg, min(5, h/7), border)
    pad = spec.get('padding', 4)
    inner_w, inner_h = max(1, w-2*pad), max(1, h-2*pad)
    bx0, by0, bx1, by1 = bbox if spec.get('trim_transparency', True) else (0,0,iw,ih)
    bw, bh = bx1-bx0, by1-by0
    scale = min(inner_w/bw, inner_h/bh)
    # Center the visible source bounds, preserving its exact aspect ratio.
    vx, vy = x+(w-bw*scale)/2, y+(h-bh*scale)/2
    ix, iy = vx-bx0*scale, vy-by0*scale
    c = pdf.c
    c.saveState()
    clip = c.beginPath()
    clip.roundRect(x+1, pdf.h-y-h+1, w-2, h-2, max(1,min(4,h/7)))
    c.clipPath(clip, stroke=0, fill=0)
    c.drawImage(ImageReader(str(ASSETS/filename)), ix, pdf.h-iy-ih*scale,
                iw*scale, ih*scale, mask='auto')
    c.restoreState()


@lru_cache(maxsize=16)
def _svg(filename):
    return svg2rlg(str(ASSETS / filename))

def _draw_svg(pdf, filename, spec, x, y, w, h):
    drawing = _svg(filename)
    bg = spec.get('background', '#FFFFFF')
    pdf.rect(x, y, w, h, bg, min(5,h/7), '#445862' if bg != '#FFFFFF' else '#DCE1DE')
    pad = spec.get('padding', 4)
    bx0, by0, bx1, by1 = drawing.getBounds()
    bw, bh = bx1-bx0, by1-by0
    scale = min((w-2*pad)/bw,(h-2*pad)/bh)
    c = pdf.c
    c.saveState()
    c.translate(x+(w-bw*scale)/2-bx0*scale, pdf.h-y-h+(h-bh*scale)/2-by0*scale)
    c.scale(scale, scale)
    renderPDF.draw(drawing, c, 0, 0)
    c.restoreState()
