from pathlib import Path
from PIL import Image,ImageDraw
import fitz,json
R=Path(__file__).resolve().parent
reports=[]
for f in (R/'output').glob('*.pdf'):
 d=fitz.open(f);bad=[];bounds=[]
 for pi,p in enumerate(d):
  spans=[s for b in p.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s['text'].strip()]
  for i,s in enumerate(spans):
   r=fitz.Rect(s['bbox'])
   if r.x0<20 or r.x1>p.rect.width-20 or r.y0<10 or r.y1>p.rect.height-10:bounds.append([pi+1,s['text'],list(r)])
   for t in spans[i+1:]:
    q=fitz.Rect(t['bbox']);a=r&q
    if not a.is_empty and a.width>3 and a.height>3 and a.get_area()/min(r.get_area(),q.get_area())>.18:bad.append([pi+1,s['text'],t['text']])
 reports.append({'file':f.name,'collisions':bad,'bounds':bounds})
 if 'Complete' in f.name:
  for st in range(0,len(d),12):
   im=Image.new('RGB',(1500,4*285),'#ddd');draw=ImageDraw.Draw(im)
   for j in range(min(12,len(d)-st)):
    pix=d[st+j].get_pixmap(matrix=fitz.Matrix(.43,.43));pg=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);pg.thumbnail((495,260));x=j%3*500;y=j//3*285;im.paste(pg,(x,y+20));draw.text((x+10,y+3),str(st+j+1),fill='black')
   im.save(R/'qa'/f'sheet_{st//12}.jpg')
 for i in ([0,3] if 'Executive' in f.name else [0,9,14,22,31,36]):
  d[i].get_pixmap().save(R/'qa'/f'{"exec" if "Executive" in f.name else "full"}_{i+1}.png')
(R/'qa/review.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports))
