from reportlab.lib.colors import HexColor
H=841.89
INK='#303632'
def col(s):return HexColor(s)
def rect(c,x,y,w,h,fill):
 c.setFillColor(col(fill));c.rect(x,H-y-h,w,h,fill=1,stroke=0)
def line(c,x,y,x2,y2,color,width=.5):
 c.setStrokeColor(col(color));c.setLineWidth(width);c.line(x,H-y,x2,H-y2)

def star(c,cx,cy,r,color,rotation=0):
 import math
 p=c.beginPath()
 for k in range(10):
  a=math.pi/2+rotation+k*math.pi/5;rr=r if k%2==0 else r*.4;xx=cx+rr*math.cos(a);yy=H-cy+rr*math.sin(a)
  if k==0:p.moveTo(xx,yy)
  else:p.lineTo(xx,yy)
 p.close();c.setFillColor(col(color));c.drawPath(p,stroke=0,fill=1)
def flag(c,k,x,y,w=20,h=13):
 c.saveState();path=c.beginPath();path.rect(x,H-y-h,w,h);c.clipPath(path,stroke=0,fill=0)
 rect(c,x,y,w,h,'#FFFFFF')
 if k in ('FR','IT'):
  rect(c,x,y,w/3,h,'#21458B' if k=='FR' else '#178252');rect(c,x+2*w/3,y,w/3,h,'#CB3942')
 elif k in ('DE','NL'):
  colors=['#1D2429','#C73340','#EFC349'] if k=='DE' else ['#B53642','#FFFFFF','#28528C']
  for i,co in enumerate(colors):rect(c,x,y+i*h/3,w,h/3,co)
 elif k=='ES':
  rect(c,x,y,w,h,'#AF2638');rect(c,x,y+h/4,w,h/2,'#F4C545');rect(c,x+w*.25,y+h*.38,2,h*.25,'#B54041')
 elif k=='JP':
  c.setFillColor(col('#BB3042'));c.circle(x+w/2,H-y-h/2,h*.29,stroke=0,fill=1)
 elif k=='CN':
  rect(c,x,y,w,h,'#C53636');star(c,x+w*.23,y+h*.3,h*.2,'#F5D35A')
  for xx,yy in [(.42,.15),(.5,.3),(.5,.48),(.42,.6)]:star(c,x+w*xx,y+h*yy,h*.065,'#F5D35A')
 elif k=='IN':
  rect(c,x,y,w,h/3,'#E9A145');rect(c,x,y+2*h/3,w,h/3,'#36845C');c.setStrokeColor(col('#284C85'));c.setLineWidth(.45);c.circle(x+w/2,H-y-h/2,h*.13,stroke=1,fill=0)
 elif k=='BR':
  rect(c,x,y,w,h,'#328365');p=c.beginPath();p.moveTo(x+w/2,H-y-h*.12);p.lineTo(x+w*.9,H-y-h/2);p.lineTo(x+w/2,H-y-h*.88);p.lineTo(x+w*.1,H-y-h/2);p.close();c.setFillColor(col('#F4CF59'));c.drawPath(p,stroke=0,fill=1);c.setFillColor(col('#2D5090'));c.circle(x+w/2,H-y-h/2,h*.23,stroke=0,fill=1);line(c,x+w*.37,y+h*.45,x+w*.63,y+h*.55,'#FFFFFF',.6)
 elif k=='GB':
  rect(c,x,y,w,h,'#294B80')
  for width,color in [(3.6,'#FFFFFF'),(1.3,'#BD3948')]:
   line(c,x,y,x+w,y+h,color,width);line(c,x+w,y,x,y+h,color,width)
  rect(c,x+w*.4,y,w*.2,h,'#FFFFFF');rect(c,x,y+h*.35,w,h*.3,'#FFFFFF');rect(c,x+w*.45,y,w*.1,h,'#BD3948');rect(c,x,y+h*.42,w,h*.16,'#BD3948')
 elif k=='GR':
  for i in range(0,9,2):rect(c,x,y+i*h/9,w,h/9,'#37649C')
  rect(c,x,y,w*.45,h*5/9,'#37649C');rect(c,x+w*.19,y,w*.07,h*5/9,'#FFFFFF');rect(c,x,y+h*2/9,w*.45,h/9,'#FFFFFF')
 elif k=='KR':
  cx=x+w/2;cy=H-y-h/2;r=h*.23
  c.setFillColor(col('#C94450'));c.wedge(cx-r,cy-r,cx+r,cy+r,0,180,stroke=0,fill=1);c.setFillColor(col('#37629A'));c.wedge(cx-r,cy-r,cx+r,cy+r,180,180,stroke=0,fill=1)
  for dx,dy in [(.15,.22),(.76,.22),(.15,.68),(.76,.68)]:
   for j in range(3):line(c,x+w*dx,y+h*dy+j*.8,x+w*dx+2.6,y+h*dy+j*.8,'#26333A',.45)
 c.restoreState();c.setStrokeColor(col('#CDD5D2'));c.setLineWidth(.3);c.rect(x,H-y-h,w,h,stroke=1,fill=0)
def language_grid(c,y,ats=False):
 langs=[('BR','Portuguese'),('GB','English'),('ES','Spanish'),('CN','Mandarin Chinese'),('FR','French'),('DE','German'),('IT','Italian'),('NL','Dutch'),('GR','Greek'),('IN','Hindi'),('JP','Japanese'),('KR','Korean')]
 for i,(code,name) in enumerate(langs):
  x=40+(i%4)*130;yy=y+(i//4)*27
  flag(c,code,x,yy+2);text(c,name,x+26,yy+3,7.6,'NB',INK)
 return y+83
