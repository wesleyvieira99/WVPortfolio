# Wesley Vieira | Software & Agentic AI Engineering Leadership

Editable CV and portfolio source, updated October 7, 2026.

The executive CV presents selected career evidence for applications. The complete
portfolio preserves the detailed career narrative, technical expertise, education,
course catalog, articles, recommendations, awards and press coverage. The design
uses graphite, warm neutral surfaces, restrained colour accents and consistent
brand tiles, with searchable text and clickable navigation.

## Current content

- 446 consolidated course and certification records.
- 27 education programs, excluding Estácio as requested and consolidating the
  duplicate Duke LLMOps record.
- 13 technical articles with covers, summaries, topic tags and direct links.
- 8 career roles and 11 technical domains.
- 5 recommendations, 3 award photographs and 5 press stories.
- Volunteering and 12 languages, displayed with flags and names.

The final record files in `assets/` are authoritative. Supporting historical JSON
files are retained for provenance and comparison; `build.py` reads
`editorial_content.json`, `education_final.json` and `catalog_final.json`.

## Build and review

Use Python 3 with these packages installed:

```bash
python -m pip install reportlab pymupdf pillow svglib
mkdir -p output qa
python build.py
python qa_validate.py
python review.py
```

Inspect the rendered page images in `qa/` and the generated PDFs in `output/`.
Review `qa/validation.json` for content, source-link and internal-navigation checks,
and `qa/review.json` for detected text collisions and page-boundary issues. These
reports describe the build that produced them; rerun the checks after any edit.
`source/` contains the earlier complete portfolio used as a comparison baseline.
PDF page transitions are optional and depend on the reader application.

## Logos, assets and portability

`brand_assets.py` draws the original image or SVG marks inside consistent logo
tiles. `assets/brand_config.json` maps providers and source filenames to the
correct marks and backgrounds. Its keys and filenames must remain aligned with
the files in `assets/`. Providers not identified in the source use a neutral
certificate symbol.

The archive includes all assets and fonts without renaming or deduplicating logo
files. The brand configuration is copied unchanged. Only local logo paths in the
archived final education and course records are normalized to
`assets/<filename>`; their other fields and all working source files are preserved.
The renderer itself resolves image references against the packaged assets folder.

After completing the final build and visual review, create the source archive:

```bash
python package_source.py
```

The script writes
`output/Wesley_Vieira_Engineering_Leader_Editable_Source.zip`, verifies referenced
brand files before packaging and stops if the source archive would exceed 10 MB.
Generated PDFs are delivered separately and are not duplicated in the source ZIP.

Atualização 2026-10-08: 448 registros, conclusão de Boost Your Leadership Impact e novo certificado de agentes de IA. Consulte assets/update_manifest.json.
